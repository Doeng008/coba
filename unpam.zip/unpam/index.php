
<!DOCTYPE html>
<html>
<head>
    <title>tugas crud lsp</title>
</head>

<body>
    <header>
        <h3>Tugas Crud Lsp</h3>
        <h1>Universitas Pamulang</h1>
    </header>

    <h4>Menu</h4>
    <nav>
        <ul> 
        <td><a href="mahasiswa.php">Mahasiswa</a></td>
        <td><a href="matakuliah.php">Matakuliah</a></td>
        <td><a href="dosen.php">Dosen</a></td>
        <td><a href="perkuliahan.php">Perkuliahan</a></td>
        <td><a href="logout.php">Keluar</a></td>
        </ul>
    </nav>

    </body>
</html>